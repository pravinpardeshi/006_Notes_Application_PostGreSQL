--
-- PostgreSQL database dump
--

\restrict A0e8cx25fZqd50Nn5p2V22k6rOWS5vWZcXOCFVv2nKaHotNxhMYe7ovoAQat9hx

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.sub_categories DROP CONSTRAINT IF EXISTS sub_categories_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_sub_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_category_id_fkey;
DROP TRIGGER IF EXISTS trg_notes_updated_at ON public.notes;
DROP INDEX IF EXISTS public.ix_note_images_id;
DROP INDEX IF EXISTS public.idx_sub_categories_category;
DROP INDEX IF EXISTS public.idx_notes_title;
DROP INDEX IF EXISTS public.idx_notes_text;
DROP INDEX IF EXISTS public.idx_notes_sub_category;
DROP INDEX IF EXISTS public.idx_notes_priority;
DROP INDEX IF EXISTS public.idx_notes_category;
DROP INDEX IF EXISTS public.idx_notes_archived;
ALTER TABLE IF EXISTS ONLY public.sub_categories DROP CONSTRAINT IF EXISTS sub_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.note_images DROP CONSTRAINT IF EXISTS note_images_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_name_key;
ALTER TABLE IF EXISTS public.sub_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.note_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.sub_categories_id_seq;
DROP TABLE IF EXISTS public.sub_categories;
DROP SEQUENCE IF EXISTS public.notes_id_seq;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.note_images_id_seq;
DROP TABLE IF EXISTS public.note_images;
DROP SEQUENCE IF EXISTS public.categories_id_seq;
DROP TABLE IF EXISTS public.categories;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP TYPE IF EXISTS public.priorityenum;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: priorityenum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.priorityenum AS ENUM (
    'low',
    'medium',
    'high'
);


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: note_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note_images (
    id integer NOT NULL,
    note_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    filepath character varying(512) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: note_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.note_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: note_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.note_images_id_seq OWNED BY public.note_images.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    note_text text NOT NULL,
    priority public.priorityenum DEFAULT 'medium'::public.priorityenum,
    is_archived boolean DEFAULT false,
    tags character varying(500),
    color character varying(7),
    category_id integer,
    sub_category_id integer,
    note_date date DEFAULT CURRENT_DATE,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    note_time character varying(5)
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: sub_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sub_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    category_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: sub_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sub_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sub_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sub_categories_id_seq OWNED BY public.sub_categories.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: note_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_images ALTER COLUMN id SET DEFAULT nextval('public.note_images_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: sub_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_categories ALTER COLUMN id SET DEFAULT nextval('public.sub_categories_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, description, created_at) FROM stdin;
1	Notes	General notes	2026-05-26 22:28:51.38806-04
\.


--
-- Data for Name: note_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note_images (id, note_id, filename, filepath, created_at) FROM stdin;
4	4	image2.jpeg	uploads/20260604094506247290_image2.jpeg	2026-06-04 09:45:06.246781-04
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, title, note_text, priority, is_archived, tags, color, category_id, sub_category_id, note_date, created_at, updated_at, note_time) FROM stdin;
1	Neil's Shaving Razor	For Neil's Braun Shaver, 2 years of warranty has been purchased.\n\nShaver was received on 26th May, 2026. Warranty should be valid till 25th May, 2028	high	f	Electronic item	#8ff0a4	1	1	2026-05-27	2026-05-26 22:35:12.239629-04	2026-05-27 13:03:48.675372-04	\N
4	ImageTest Note	This note has an image	medium	f	test	#4f46e5	1	5	2026-06-03	2026-06-03 19:05:38.195583-04	2026-06-03 22:04:19.319071-04	\N
2	EDITED VIA FORM STRING	Updated text	high	f	System Generated test note	#4f46e5	1	5	2026-05-27	2026-05-26 22:41:35.687506-04	2026-06-04 21:55:55.82191-04	\N
5	New Note	Timestamp	medium	f	Sample	#4f46e5	1	3	2026-06-05	2026-06-05 10:21:58.815885-04	2026-06-05 10:21:58.815885-04	10:21
\.


--
-- Data for Name: sub_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sub_categories (id, name, description, category_id, created_at) FROM stdin;
1	Online Shopping items	\N	1	2026-05-26 22:29:12.025327-04
3	Comic Books	\N	1	2026-06-03 19:12:25.524047-04
4	Reading	For Books	1	2026-06-03 19:14:40.183885-04
5	For Testing	\N	1	2026-06-03 22:03:41.004732-04
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, true);


--
-- Name: note_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.note_images_id_seq', 4, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_id_seq', 5, true);


--
-- Name: sub_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sub_categories_id_seq', 5, true);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: note_images note_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_images
    ADD CONSTRAINT note_images_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: sub_categories sub_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_categories
    ADD CONSTRAINT sub_categories_pkey PRIMARY KEY (id);


--
-- Name: idx_notes_archived; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notes_archived ON public.notes USING btree (is_archived);


--
-- Name: idx_notes_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notes_category ON public.notes USING btree (category_id);


--
-- Name: idx_notes_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notes_priority ON public.notes USING btree (priority);


--
-- Name: idx_notes_sub_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notes_sub_category ON public.notes USING btree (sub_category_id);


--
-- Name: idx_notes_text; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notes_text ON public.notes USING gin (to_tsvector('english'::regconfig, note_text));


--
-- Name: idx_notes_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notes_title ON public.notes USING gin (to_tsvector('english'::regconfig, (title)::text));


--
-- Name: idx_sub_categories_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sub_categories_category ON public.sub_categories USING btree (category_id);


--
-- Name: ix_note_images_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_note_images_id ON public.note_images USING btree (id);


--
-- Name: notes trg_notes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_notes_updated_at BEFORE UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notes notes_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: notes notes_sub_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_sub_category_id_fkey FOREIGN KEY (sub_category_id) REFERENCES public.sub_categories(id) ON DELETE SET NULL;


--
-- Name: sub_categories sub_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_categories
    ADD CONSTRAINT sub_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict A0e8cx25fZqd50Nn5p2V22k6rOWS5vWZcXOCFVv2nKaHotNxhMYe7ovoAQat9hx

